const $ = id => document.getElementById(id);
let token = localStorage.getItem("ca_token");
let me = JSON.parse(localStorage.getItem("ca_user") || "null");
let mode = "login";
let socket = null;
let room = null;
let localStream = null;
let screenStream = null;
const peers = new Map();

document.querySelectorAll(".tab").forEach(b => b.onclick = () => {
  mode = b.dataset.mode;
  document.querySelectorAll(".tab").forEach(x => x.classList.toggle("active", x === b));
  document.querySelectorAll(".registerOnly").forEach(x => x.classList.toggle("hidden", mode !== "register"));
  $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
});
$("authForm").onsubmit = async e => {
  e.preventDefault();
  const body = { email: $("email").value, password: $("password").value };
  if (mode === "register") body.name = $("name").value;
  try {
    const r = await fetch(`/api/auth/${mode}`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body) });
    const d = await r.json();
    if (!r.ok) throw new Error(d.message);
    token = d.token; me = d.user;
    localStorage.setItem("ca_token", token); localStorage.setItem("ca_user", JSON.stringify(me));
    showLobby();
  } catch(e){ $("authMsg").textContent = e.message; }
};

function showLobby(){
  $("auth").classList.add("hidden"); $("meeting").classList.add("hidden"); $("lobby").classList.remove("hidden");
  $("who").textContent = me ? `Signed in as ${me.name}` : "";
}
function showAuth(){ $("lobby").classList.add("hidden"); $("meeting").classList.add("hidden"); $("auth").classList.remove("hidden"); }

async function api(url, opts={}) {
  opts.headers = {...(opts.headers||{}), Authorization:`Bearer ${token}`};
  const r = await fetch(url, opts); const d = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(d.message || "Request failed"); return d;
}
$("createRoom").onclick = async () => { try { const d=await api("/api/rooms",{method:"POST"}); joinMeeting(d.room.room_code); } catch(e){alert(e.message)} };
$("joinRoom").onclick = async () => { try { const d=await api("/api/rooms/join",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({roomCode:$("roomCode").value})}); joinMeeting(d.room.room_code); } catch(e){alert(e.message)} };
$("logout").onclick = () => { localStorage.clear(); token=null;me=null; showAuth(); };
$("leave").onclick = () => leaveMeeting();

async function joinMeeting(code){
  room = code.toUpperCase(); $("lobby").classList.add("hidden"); $("meeting").classList.remove("hidden"); $("currentRoom").textContent=room;
  await startMedia();
  socket = io({auth:{token}});
  socket.on("connect",()=>{ $("connectionStatus").textContent="Connected"; socket.emit("join-room",{roomCode:room}); });
  socket.on("connect_error",e=>{ $("connectionStatus").textContent=e.message; });
  socket.on("room-peers", list=> list.forEach(p=>createPeer(p.socketId,true,p.user)));
  socket.on("user-joined", p=> createPeer(p.socketId,false,p.user));
  socket.on("user-left", id=> removePeer(id));
  socket.on("room-users", users=>renderParticipants(users));
  socket.on("webrtc-offer", async ({from,offer})=>{ const pc=createPeer(from,false,null); await pc.setRemoteDescription(offer); const answer=await pc.createAnswer(); await pc.setLocalDescription(answer); socket.emit("webrtc-answer",{to:from,answer}); });
  socket.on("webrtc-answer", async ({from,answer})=>{ const pc=peers.get(from)?.pc; if(pc) await pc.setRemoteDescription(answer); });
  socket.on("ice-candidate", async ({from,candidate})=>{ try{await peers.get(from)?.pc.addIceCandidate(candidate)}catch{} });
  socket.on("chat-message",m=>addMessage(m));
  socket.on("whiteboard-draw",d=>drawStroke(d,false));
  socket.on("whiteboard-clear",clearBoard);
  socket.on("file-shared",renderFile);
  await loadFiles();
}
async function startMedia(){
  try { localStream=await navigator.mediaDevices.getUserMedia({video:true,audio:true}); $("localVideo").srcObject=localStream; }
  catch(e){ alert("Camera/microphone permission is required for video calling. You can still use chat/whiteboard if the browser allows."); localStream=new MediaStream(); }
}
function createPeer(id, initiator, user){
  if(peers.has(id)) return peers.get(id).pc;
  const pc=new RTCPeerConnection({iceServers:[{urls:"stun:stun.l.google.com:19302"}]});
  localStream.getTracks().forEach(t=>pc.addTrack(t,localStream));
  const card=document.createElement("div"); card.className="video-card"; card.id=`peer-${id}`;
  const v=document.createElement("video"); v.autoplay=true;v.playsInline=true;
  const label=document.createElement("span"); label.textContent=user?.name||"Participant";
  card.append(v,label); $("videos").append(card);
  peers.set(id,{pc,video:v,user});
  pc.onicecandidate=e=>{if(e.candidate)socket.emit("ice-candidate",{to:id,candidate:e.candidate})};
  pc.ontrack=e=>{v.srcObject=e.streams[0]};
  pc.onconnectionstatechange=()=>{if(["failed","closed"].includes(pc.connectionState))removePeer(id)};
  if(initiator) pc.createOffer().then(o=>pc.setLocalDescription(o)).then(()=>socket.emit("webrtc-offer",{to:id,offer:pc.localDescription}));
  return pc;
}
function removePeer(id){const p=peers.get(id);if(!p)return;p.pc.close();document.getElementById(`peer-${id}`)?.remove();peers.delete(id)}
function renderParticipants(users){$("count").textContent=`(${users.length})`;$("participants").innerHTML=users.map(x=>`<div class="participant">${escapeHtml(x.user.name)}${x.user.id===me.id?" (You)":""}</div>`).join("")}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]))}

$("mic").onclick=()=>{const t=localStream?.getAudioTracks()[0];if(t){t.enabled=!t.enabled;$("mic").textContent=t.enabled?"🎙️ Mute":"🔇 Unmute"}};
$("camera").onclick=()=>{const t=localStream?.getVideoTracks()[0];if(t){t.enabled=!t.enabled;$("camera").textContent=t.enabled?"📷 Camera Off":"📷 Camera On"}};
$("share").onclick=async()=>{
  if(!screenStream){
    try{screenStream=await navigator.mediaDevices.getDisplayMedia({video:true}); const track=screenStream.getVideoTracks()[0];
      for(const {pc} of peers.values()){const sender=pc.getSenders().find(s=>s.track?.kind==="video");if(sender)await sender.replaceTrack(track)}
      $("localVideo").srcObject=screenStream; track.onended=()=>stopShare();
    }catch{}
  }else stopShare();
};
async function stopShare(){screenStream?.getTracks().forEach(t=>t.stop());screenStream=null;const track=localStream.getVideoTracks()[0];for(const {pc} of peers.values()){const s=pc.getSenders().find(x=>x.track?.kind==="video");if(s)await s.replaceTrack(track)}$("localVideo").srcObject=localStream}

$("chatForm").onsubmit=e=>{e.preventDefault();const text=$("chatInput").value.trim();if(text&&socket){socket.emit("chat-message",{text});$("chatInput").value=""}};
function addMessage(m){const d=document.createElement("div");d.className="message";d.innerHTML=`<b>${escapeHtml(m.sender)}</b> <small>${new Date(m.at).toLocaleTimeString()}</small><br>${escapeHtml(m.text)}`;$("messages").append(d);$("messages").scrollTop=$("messages").scrollHeight}

const canvas=$("board"),ctx=canvas.getContext("2d");let drawing=false,last=null;
function pos(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height}}
canvas.addEventListener("pointerdown",e=>{drawing=true;last=pos(e)});
canvas.addEventListener("pointerup",()=>{drawing=false;last=null});canvas.addEventListener("pointerleave",()=>{drawing=false;last=null});
canvas.addEventListener("pointermove",e=>{if(!drawing)return;const p=pos(e);const d={x1:last.x,y1:last.y,x2:p.x,y2:p.y};drawStroke(d,true);last=p});
function drawStroke(d,send){ctx.strokeStyle="#111827";ctx.lineWidth=3;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(d.x1,d.y1);ctx.lineTo(d.x2,d.y2);ctx.stroke();if(send&&socket)socket.emit("whiteboard-draw",d)}
function clearBoard(){ctx.clearRect(0,0,canvas.width,canvas.height)}
$("clearBoard").onclick=()=>{clearBoard();socket?.emit("whiteboard-clear")};

$("uploadForm").onsubmit=async e=>{e.preventDefault();const f=$("file").files[0];if(!f)return;const fd=new FormData();fd.append("file",f);try{const d=await api(`/api/rooms/${room}/files`,{method:"POST",body:fd});renderFile(d.file);$("file").value=""}catch(e){alert(e.message)}};
async function loadFiles(){try{const d=await api(`/api/rooms/${room}/files`);$("files").innerHTML="";d.files.forEach(renderFile)}catch(e){}}
function renderFile(f){const d=document.createElement("div");d.className="file";d.dataset.id=f.id;d.innerHTML=`<span>📎 ${escapeHtml(f.original_name)}<br><small>${escapeHtml(f.uploader||"")}</small></span><a href="/api/files/${f.id}/download" target="_blank" rel="noopener">Download</a>`;$("files").prepend(d)}

function leaveMeeting(){if(socket)socket.disconnect();peers.forEach((_,id)=>removePeer(id));localStream?.getTracks().forEach(t=>t.stop());screenStream?.getTracks().forEach(t=>t.stop());socket=null;room=null;$("meeting").classList.add("hidden");showLobby()}

if(token&&me)showLobby(); else showAuth();
