# CodeAlpha Task 4 — Real-Time Communication App

This implementation follows the Task 4 requirements in the CodeAlpha Full Stack Development brief:
- Multi-user video calling
- Screen sharing
- File sharing
- Collaborative whiteboard
- Data encryption/security
- User authentication
- WebRTC for real-time media
- Socket.IO for real-time signaling/collaboration

## Technology
Node.js, Express.js, Socket.IO, WebRTC, MySQL, JWT, bcrypt, Multer, HTML/CSS/JavaScript.

## 1. Requirements
- Node.js 18+
- MySQL 8+
- Modern browser (Chrome/Edge/Firefox)
- Camera/microphone for video calling

## 2. Database
Open MySQL Workbench or phpMyAdmin and run `database.sql`.

Default local settings:
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=codealpha_realtime

If your MySQL root account has a password, put it in `.env`.

## 3. Install
Open CMD/PowerShell inside this folder:

npm install

Copy `.env.example` to `.env` and set:
PORT=3000
JWT_SECRET=your-long-random-secret
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=codealpha_realtime

Then:
npm start

Open:
http://localhost:3000

## 4. How to test
1. Register User A.
2. Create a room and copy its room code.
3. Open another browser/profile/incognito window.
4. Register User B.
5. Join the same room using the code.
6. Allow camera/microphone.
7. Test video/audio, mute, camera toggle and screen sharing.
8. Send chat messages.
9. Draw on the whiteboard; the strokes are broadcast in real time.
10. Upload a file and download it from the second account.

## Security implementation
- Passwords are hashed with bcrypt.
- API and Socket.IO access use JWT authentication.
- Users must be authenticated to create/join rooms and access files.
- Room membership is checked before downloads.
- File uploads are limited to 20 MB.
- Uploaded file names are sanitized.
- WebRTC media is encrypted in transit by the WebRTC/DTLS-SRTP stack in modern browsers.
- The server handles signaling; the video/audio media is peer-to-peer.

## Important deployment note
For production deployment use HTTPS/WSS. Camera, microphone and screen sharing are restricted by browsers to secure contexts (localhost is allowed for development). For larger multi-user meetings, an SFU such as mediasoup/Janus/LiveKit would scale better than a full peer-to-peer mesh.

## Submission checklist
- Source code
- MySQL database script
- README and setup guide
- Authentication
- WebRTC video/audio
- Screen sharing
- File sharing
- Whiteboard
- Socket.IO real-time communication
- Security measures
