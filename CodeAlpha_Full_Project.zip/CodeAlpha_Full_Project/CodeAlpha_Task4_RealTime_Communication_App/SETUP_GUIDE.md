# Windows Setup — Sinhala Quick Guide

## 1. MySQL database
1. Open XAMPP and start MySQL, OR open your MySQL service.
2. Open MySQL Workbench/phpMyAdmin.
3. Run `database.sql`.
4. Confirm database `codealpha_realtime` exists.

## 2. Node packages
Open PowerShell in the project folder:
`npm install`

If Windows gives EPERM for node_modules:
- close VS Code terminals running Node
- close any process using the folder
- reopen PowerShell as Administrator
- run `npm cache verify`
- run `npm install` again

## 3. Environment
Create `.env` from `.env.example`.

Example for XAMPP root MySQL with no password:
PORT=3000
JWT_SECRET=CodeAlpha_Task4_Change_This_Secret_2026
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=codealpha_realtime

## 4. Run
`npm start`

Then browser:
`http://localhost:3000`

## 5. Testing two users
Use Chrome normal window for User A and Chrome Incognito for User B. Register both accounts and join the same room.

## 6. HTTPS
Localhost works for browser media APIs. For online deployment, configure HTTPS and WSS.
