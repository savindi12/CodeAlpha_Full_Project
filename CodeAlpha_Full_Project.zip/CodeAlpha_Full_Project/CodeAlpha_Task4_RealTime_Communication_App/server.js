require("dotenv").config();

const path = require("path");
const fs = require("fs");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");
const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true, credentials: true } });

const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "dev_only_change_me";
const uploadDir = path.join(__dirname, process.env.UPLOAD_DIR || "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "codealpha_realtime",
  waitForConnections: true,
  connectionLimit: 10
});

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

function signToken(user) {
  return jwt.sign({ id: user.id, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: "8h" });
}
function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ message: "Authentication required." });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: "Invalid or expired token." });
  }
}
function roomCode() {
  return crypto.randomBytes(5).toString("hex").toUpperCase();
}
function safeName(name) {
  return path.basename(name).replace(/[^a-zA-Z0-9._ -]/g, "_").slice(0, 180);
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}-${crypto.randomBytes(8).toString("hex")}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }
});

app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 6)
      return res.status(400).json({ message: "Name, email and password (minimum 6 characters) are required." });
    const normalized = email.trim().toLowerCase();
    const [exists] = await pool.query("SELECT id FROM users WHERE email=?", [normalized]);
    if (exists.length) return res.status(409).json({ message: "Email is already registered." });
    const hash = await bcrypt.hash(password, 12);
    const [result] = await pool.query(
      "INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
      [name.trim(), normalized, hash]
    );
    const user = { id: result.insertId, name: name.trim(), email: normalized };
    res.json({ user, token: signToken(user) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Registration failed." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.query("SELECT id,name,email,password_hash FROM users WHERE email=?", [
      String(email || "").trim().toLowerCase()
    ]);
    if (!rows.length || !(await bcrypt.compare(password || "", rows[0].password_hash)))
      return res.status(401).json({ message: "Invalid email or password." });
    const user = { id: rows[0].id, name: rows[0].name, email: rows[0].email };
    res.json({ user, token: signToken(user) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Login failed." });
  }
});

app.get("/api/me", auth, async (req, res) => res.json({ user: req.user }));

app.post("/api/rooms", auth, async (req, res) => {
  try {
    const code = roomCode();
    const [r] = await pool.query("INSERT INTO rooms(room_code,created_by) VALUES(?,?)", [code, req.user.id]);
    await pool.query("INSERT INTO room_members(room_id,user_id) VALUES(?,?)", [r.insertId, req.user.id]);
    res.json({ room: { id: r.insertId, room_code: code } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Could not create room." });
  }
});

app.post("/api/rooms/join", auth, async (req, res) => {
  try {
    const code = String(req.body.roomCode || "").trim().toUpperCase();
    const [rooms] = await pool.query("SELECT id,room_code FROM rooms WHERE room_code=?", [code]);
    if (!rooms.length) return res.status(404).json({ message: "Room not found." });
    await pool.query("INSERT IGNORE INTO room_members(room_id,user_id) VALUES(?,?)", [rooms[0].id, req.user.id]);
    res.json({ room: rooms[0] });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Could not join room." });
  }
});

app.get("/api/rooms/:code/files", auth, async (req, res) => {
  const code = req.params.code.toUpperCase();
  const [rows] = await pool.query(`
    SELECT sf.id,sf.original_name,sf.mime_type,sf.size_bytes,sf.created_at,u.name AS uploader
    FROM shared_files sf
    JOIN rooms r ON r.id=sf.room_id
    LEFT JOIN users u ON u.id=sf.uploaded_by
    WHERE r.room_code=? ORDER BY sf.created_at DESC`, [code]);
  res.json({ files: rows });
});

app.post("/api/rooms/:code/files", auth, upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file selected." });
    const code = req.params.code.toUpperCase();
    const [rooms] = await pool.query("SELECT id FROM rooms WHERE room_code=?", [code]);
    if (!rooms.length) {
      fs.unlinkSync(req.file.path);
      return res.status(404).json({ message: "Room not found." });
    }
    const [members] = await pool.query(
      "SELECT 1 FROM room_members WHERE room_id=? AND user_id=?",
      [rooms[0].id, req.user.id]
    );
    if (!members.length) {
      fs.unlinkSync(req.file.path);
      return res.status(403).json({ message: "Join the room first." });
    }
    const [r] = await pool.query(`
      INSERT INTO shared_files(room_id,uploaded_by,original_name,stored_name,mime_type,size_bytes)
      VALUES(?,?,?,?,?,?)`,
      [rooms[0].id, req.user.id, safeName(req.file.originalname), req.file.filename, req.file.mimetype, req.file.size]
    );
    const file = { id: r.insertId, original_name: safeName(req.file.originalname), mime_type: req.file.mimetype, size_bytes: req.file.size, uploader: req.user.name };
    io.to(`room:${code}`).emit("file-shared", file);
    res.json({ file });
  } catch (e) {
    console.error(e);
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    res.status(500).json({ message: "File upload failed." });
  }
});

app.get("/api/files/:id/download", auth, async (req, res) => {
  const [rows] = await pool.query(`
    SELECT sf.*, r.room_code FROM shared_files sf
    JOIN rooms r ON r.id=sf.room_id WHERE sf.id=?`, [req.params.id]);
  if (!rows.length) return res.status(404).end();
  const [member] = await pool.query(
    "SELECT 1 FROM room_members WHERE room_id=? AND user_id=?",
    [rows[0].room_id, req.user.id]
  );
  if (!member.length) return res.status(403).end();
  res.download(path.join(uploadDir, rows[0].stored_name), rows[0].original_name);
});

io.use((socket, next) => {
  try {
    const token = socket.handshake.auth?.token;
    socket.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    next(new Error("Unauthorized socket connection."));
  }
});

const peers = new Map(); // room -> Map(socketId, user)

io.on("connection", socket => {
  socket.on("join-room", async ({ roomCode }) => {
    const code = String(roomCode || "").toUpperCase();
    const [rooms] = await pool.query("SELECT id FROM rooms WHERE room_code=?", [code]);
    if (!rooms.length) return socket.emit("room-error", "Room does not exist.");
    const [member] = await pool.query(
      "SELECT 1 FROM room_members WHERE room_id=? AND user_id=?", [rooms[0].id, socket.user.id]
    );
    if (!member.length) return socket.emit("room-error", "You must join the room first.");

    socket.join(`room:${code}`);
    socket.data.roomCode = code;
    if (!peers.has(code)) peers.set(code, new Map());
    const roomPeers = peers.get(code);
    const existing = [...roomPeers.entries()].map(([socketId, user]) => ({ socketId, user }));
    socket.emit("room-peers", existing);
    roomPeers.set(socket.id, { id: socket.user.id, name: socket.user.name });
    socket.to(`room:${code}`).emit("user-joined", {
      socketId: socket.id, user: { id: socket.user.id, name: socket.user.name }
    });
    io.to(`room:${code}`).emit("room-users", [...roomPeers.entries()].map(([socketId, user]) => ({ socketId, user })));
  });

  // WebRTC signaling: offer/answer/ICE only; media stays peer-to-peer.
  socket.on("webrtc-offer", ({ to, offer }) => io.to(to).emit("webrtc-offer", { from: socket.id, offer }));
  socket.on("webrtc-answer", ({ to, answer }) => io.to(to).emit("webrtc-answer", { from: socket.id, answer }));
  socket.on("ice-candidate", ({ to, candidate }) => io.to(to).emit("ice-candidate", { from: socket.id, candidate }));

  socket.on("chat-message", ({ text }) => {
    const code = socket.data.roomCode;
    if (!code || !text?.trim()) return;
    io.to(`room:${code}`).emit("chat-message", {
      id: crypto.randomUUID(), sender: socket.user.name, text: String(text).trim().slice(0, 2000),
      at: new Date().toISOString()
    });
  });

  // Whiteboard strokes are small JSON objects broadcast to everyone in the room.
  socket.on("whiteboard-draw", data => {
    const code = socket.data.roomCode;
    if (code) socket.to(`room:${code}`).emit("whiteboard-draw", data);
  });
  socket.on("whiteboard-clear", () => {
    const code = socket.data.roomCode;
    if (code) io.to(`room:${code}`).emit("whiteboard-clear");
  });

  socket.on("disconnect", () => {
    const code = socket.data.roomCode;
    if (!code || !peers.has(code)) return;
    const roomPeers = peers.get(code);
    roomPeers.delete(socket.id);
    socket.to(`room:${code}`).emit("user-left", socket.id);
    io.to(`room:${code}`).emit("room-users", [...roomPeers.entries()].map(([socketId, user]) => ({ socketId, user })));
    if (!roomPeers.size) peers.delete(code);
  });
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

server.listen(PORT, () => console.log(`CodeAlpha Task 4 server running at http://localhost:${PORT}`));
