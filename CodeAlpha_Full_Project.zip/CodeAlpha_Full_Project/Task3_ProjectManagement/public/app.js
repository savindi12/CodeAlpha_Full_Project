/* =====================================================
   PROJECTFLOW APP
===================================================== */


/* =====================================================
   STATE
===================================================== */

let token =
    localStorage.getItem(
        'projectflow_token'
    );


/* =====================================================
   DOM HELPER
===================================================== */

const $ = selector =>
    document.querySelector(selector);


/* =====================================================
   AUTH HEADERS
===================================================== */

function authHeaders() {

    const headers = {
        'Content-Type':
            'application/json'
    };

    if (token) {

        headers.Authorization =
            'Bearer ' + token;
    }

    return headers;
}


/* =====================================================
   SAFE JSON
===================================================== */

async function safeJson(response) {

    try {

        return await response.json();

    } catch {

        return {
            message:
                `Server returned HTTP ${response.status}`
        };
    }
}


/* =====================================================
   ESCAPE HTML
===================================================== */

function escapeHtml(value) {

    return String(
        value ?? ''
    ).replace(
        /[&<>"']/g,
        character => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[character])
    );
}


/* =====================================================
   DATE
===================================================== */

function formatDate(value) {

    if (!value) {
        return '';
    }

    const date =
        new Date(value);

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {
        return '';
    }

    return date.toLocaleString();
}


/* =====================================================
   TOAST
===================================================== */

function toast(message) {

    const container =
        $('#toastContainer');

    if (!container) {
        return;
    }

    const item =
        document.createElement('div');

    item.className =
        'toast';

    item.textContent =
        message;

    container.appendChild(
        item
    );

    setTimeout(() => {

        item.remove();

    }, 3000);
}


/* =====================================================
   AUTH MODAL
===================================================== */

function openAuth() {

    const modal =
        $('#modal');

    const box =
        $('#box');


    if (!modal || !box) {

        console.error(
            'Authentication modal not found.'
        );

        return;
    }


    box.innerHTML = `

        <h2>
            Account
        </h2>

        <p class="muted">
            Register a new account or login.
        </p>


        <label>
            Name
        </label>

        <input
            id="authName"
            class="input"
            type="text"
            placeholder="Your name"
        >


        <label>
            Email
        </label>

        <input
            id="authEmail"
            class="input"
            type="email"
            placeholder="Email"
        >


        <label>
            Password
        </label>

        <input
            id="authPassword"
            class="input"
            type="password"
            placeholder="Password"
        >


        <label>
            Bio
        </label>

        <textarea
            id="authBio"
            class="input"
            placeholder="Short bio"
        ></textarea>


        <div class="row">

            <button
                class="btn"
                type="button"
                onclick="register()"
            >
                Register
            </button>


            <button
                class="btn secondary"
                type="button"
                onclick="login()"
            >
                Login
            </button>


            <button
                class="btn secondary"
                type="button"
                onclick="closeAuth()"
            >
                Close
            </button>

        </div>

    `;


    modal.classList.remove(
        'hidden'
    );
}


/* =====================================================
   CLOSE AUTH
===================================================== */

function closeAuth() {

    $('#modal')?.classList.add(
        'hidden'
    );
}


/* =====================================================
   REGISTER
===================================================== */

async function register() {

    const name =
        $('#authName')?.value.trim();

    const email =
        $('#authEmail')?.value.trim();

    const password =
        $('#authPassword')?.value;

    const bio =
        $('#authBio')?.value.trim();


    if (
        !name ||
        !email ||
        !password
    ) {

        toast(
            'Name, email and password are required.'
        );

        return;
    }


    try {

        const response =
            await fetch(
                '/api/register',
                {
                    method: 'POST',

                    headers: {
                        'Content-Type':
                            'application/json'
                    },

                    body:
                        JSON.stringify({
                            name,
                            email,
                            password,
                            bio
                        })
                }
            );


        const data =
            await safeJson(
                response
            );


        if (!response.ok) {

            toast(
                data.message ||
                'Registration failed.'
            );

            return;
        }


        toast(
            data.message ||
            'Registration successful.'
        );


        $('#authPassword').value =
            '';

    } catch (error) {

        console.error(
            error
        );

        toast(
            'Cannot connect to server.'
        );
    }
}


/* =====================================================
   LOGIN
===================================================== */

async function login() {

    const email =
        $('#authEmail')?.value.trim();

    const password =
        $('#authPassword')?.value;


    if (
        !email ||
        !password
    ) {

        toast(
            'Enter email and password.'
        );

        return;
    }


    try {

        const response =
            await fetch(
                '/api/login',
                {
                    method: 'POST',

                    headers: {
                        'Content-Type':
                            'application/json'
                    },

                    body:
                        JSON.stringify({
                            email,
                            password
                        })
                }
            );


        const data =
            await safeJson(
                response
            );


        if (
            !response.ok ||
            !data.token
        ) {

            toast(
                data.message ||
                'Login failed.'
            );

            return;
        }


        token =
            data.token;


        localStorage.setItem(
            'projectflow_token',
            token
        );


        closeAuth();

        updateAuthUI();


        toast(
            'Login successful.'
        );


        await loadProjects();

        await loadNotifications();

    } catch (error) {

        console.error(
            error
        );

        toast(
            'Cannot connect to server.'
        );
    }
}


/* =====================================================
   LOGOUT
===================================================== */

function logout() {

    token = null;


    localStorage.removeItem(
        'projectflow_token'
    );


    updateAuthUI();


    $('#projectsList').innerHTML = `

        <div class="card empty">
            Login to view your projects.
        </div>

    `;


    $('#notificationsList').innerHTML = `

        <div class="card empty">
            Login to view notifications.
        </div>

    `;


    $('#notificationBadge')
        ?.classList.add(
            'hidden'
        );


    toast(
        'Logged out.'
    );
}


/* =====================================================
   UPDATE AUTH UI
===================================================== */

function updateAuthUI() {

    const loginBtn =
        $('#loginBtn');

    const logoutBtn =
        $('#logoutBtn');

    const projectSection =
        $('#projectSection');


    if (token) {

        loginBtn?.classList.add(
            'hidden'
        );

        logoutBtn?.classList.remove(
            'hidden'
        );

        projectSection?.classList.remove(
            'hidden'
        );

    } else {

        loginBtn?.classList.remove(
            'hidden'
        );

        logoutBtn?.classList.add(
            'hidden'
        );

        projectSection?.classList.add(
            'hidden'
        );
    }
}


/* =====================================================
   CREATE PROJECT
===================================================== */

async function createProject() {

    if (!token) {

        toast(
            'Please login first.'
        );

        return;
    }


    const name =
        $('#projectName')
            ?.value
            .trim();


    const description =
        $('#projectDescription')
            ?.value
            .trim();


    if (!name) {

        toast(
            'Enter a project name.'
        );

        return;
    }


    try {

        const response =
            await fetch(
                '/api/projects',
                {
                    method: 'POST',

                    headers:
                        authHeaders(),

                    body:
                        JSON.stringify({
                            name,
                            description
                        })
                }
            );


        const data =
            await safeJson(
                response
            );


        if (
            response.status === 401
        ) {

            handleUnauthorized();

            return;
        }


        if (!response.ok) {

            toast(
                data.message ||
                'Could not create project.'
            );

            return;
        }


        $('#projectName').value =
            '';

        $('#projectDescription').value =
            '';


        toast(
            data.message ||
            'Project created successfully.'
        );


        loadProjects();

    } catch (error) {

        console.error(
            error
        );

        toast(
            'Cannot connect to server.'
        );
    }
}


/* =====================================================
   LOAD PROJECTS
===================================================== */

async function loadProjects() {

    const list =
        $('#projectsList');


    if (!list) {
        return;
    }


    if (!token) {

        list.innerHTML = `

            <div class="card empty">
                Login to view your projects.
            </div>

        `;

        return;
    }


    list.innerHTML = `

        <div class="card empty">
            Loading projects...
        </div>

    `;


    try {

        const response =
            await fetch(
                '/api/projects',
                {
                    method: 'GET',

                    headers:
                        authHeaders()
                }
            );


        if (
            response.status === 401
        ) {

            handleUnauthorized();

            return;
        }


        const data =
            await safeJson(
                response
            );


        if (!response.ok) {

            throw new Error(
                data.message ||
                'Failed to load projects.'
            );
        }


        const projects =
            Array.isArray(data)
                ? data
                : (
                    Array.isArray(
                        data.projects
                    )
                        ? data.projects
                        : []
                );


        renderProjects(
            projects
        );

    } catch (error) {

        console.error(
            error
        );


        list.innerHTML = `

            <div class="card">

                <strong>
                    Could not load projects.
                </strong>

                <p class="muted">
                    ${escapeHtml(
                        error.message
                    )}
                </p>


                <button
                    class="btn"
                    onclick="loadProjects()"
                >
                    Retry
                </button>

            </div>

        `;
    }
}


/* =====================================================
   RENDER PROJECTS
===================================================== */

function renderProjects(
    projects
) {

    const list =
        $('#projectsList');


    if (!projects.length) {

        list.innerHTML = `

            <div class="card empty">
                No projects yet.
            </div>

        `;

        return;
    }


    list.innerHTML =
        projects
            .map(project => {

                const id =
                    Number(
                        project.id
                    );


                return `

                    <div
                        class="card project-card"
                    >

                        <h3
                            class="project-title"
                        >
                            ${escapeHtml(
                                project.name ||
                                project.title ||
                                'Untitled Project'
                            )}
                        </h3>


                        <p
                            class="project-description"
                        >
                            ${escapeHtml(
                                project.description ||
                                'No description.'
                            )}
                        </p>


                        <div class="row">

                            <button
                                class="btn"
                                type="button"
                                onclick="openProject(${id})"
                            >
                                Open Project
                            </button>


                            <button
                                class="btn secondary task-btn"
                                type="button"
                                onclick="loadProjectTasks(${id})"
                            >
                                📋 Tasks
                            </button>

                        </div>


                        <div
                            id="project-${id}-tasks"
                            class="task-area"
                        ></div>

                    </div>

                `;

            })
            .join('');
}


/* =====================================================
   OPEN PROJECT
===================================================== */

async function openProject(
    projectId
) {

    await loadProjectTasks(
        projectId
    );


    const area =
        document.querySelector(
            `#project-${projectId}-tasks`
        );


    area?.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
    });
}


/* =====================================================
   LOAD PROJECT TASKS
===================================================== */

async function loadProjectTasks(
    projectId
) {

    const container =
        document.querySelector(
            `#project-${projectId}-tasks`
        );


    if (!container) {

        toast(
            'Task area not found.'
        );

        return;
    }


    container.innerHTML = `

        <div class="card">

            <p class="muted">
                Loading tasks...
            </p>

        </div>

    `;


    try {

        const response =
            await fetch(
                `/api/projects/${encodeURIComponent(
                    projectId
                )}/tasks`,
                {
                    method: 'GET',

                    headers:
                        authHeaders()
                }
            );


        if (
            response.status === 401
        ) {

            handleUnauthorized();

            return;
        }


        const data =
            await safeJson(
                response
            );


        if (!response.ok) {

            throw new Error(
                data.message ||
                `Tasks request failed: HTTP ${response.status}`
            );
        }


        const tasks =
            Array.isArray(data)
                ? data
                : (
                    Array.isArray(
                        data.tasks
                    )
                        ? data.tasks
                        : []
                );


        renderTaskArea(
            container,
            projectId,
            tasks
        );


    } catch (error) {

        console.error(
            'Task loading error:',
            error
        );


        container.innerHTML = `

            <div class="card">

                <strong>
                    Unable to load tasks.
                </strong>

                <p class="muted">
                    ${escapeHtml(
                        error.message
                    )}
                </p>


                <button
                    class="btn"
                    type="button"
                    onclick="loadProjectTasks(${projectId})"
                >
                    Retry
                </button>

            </div>

        `;
    }
}


/* =====================================================
   RENDER TASK AREA
===================================================== */

function renderTaskArea(
    container,
    projectId,
    tasks
) {

    container.innerHTML = `

        <!-- CREATE TASK FORM -->

        <div class="task-create">

            <h3>
                + Create New Task
            </h3>


            <label>
                Task title
            </label>

            <input
                id="task-title-${projectId}"
                class="input"
                type="text"
                placeholder="Task title"
            >


            <label>
                Description
            </label>

            <textarea
                id="task-description-${projectId}"
                class="input"
                placeholder="Task description"
            ></textarea>


            <label>
                Status
            </label>

            <select
                id="task-status-${projectId}"
                class="input"
            >

                <option value="todo">
                    To Do
                </option>

                <option value="in_progress">
                    In Progress
                </option>

                <option value="done">
                    Done
                </option>

            </select>


            <label>
                Assign to user ID
            </label>

            <input
                id="task-assignee-${projectId}"
                class="input"
                type="number"
                min="1"
                placeholder="Optional user ID"
            >


            <button
                class="btn"
                type="button"
                onclick="createTask(${projectId})"
            >
                + Create Task
            </button>

        </div>


        <!-- TASK BOARD -->

        <div class="board">

            ${renderTaskColumn(
                'To Do',
                tasks.filter(
                    task =>
                        normalizeStatus(
                            task.status
                        ) === 'todo'
                )
            )}


            ${renderTaskColumn(
                'In Progress',
                tasks.filter(
                    task =>
                        normalizeStatus(
                            task.status
                        ) === 'in_progress'
                )
            )}


            ${renderTaskColumn(
                'Done',
                tasks.filter(
                    task =>
                        normalizeStatus(
                            task.status
                        ) === 'done'
                )
            )}

        </div>

    `;
}


/* =====================================================
   NORMALIZE STATUS
===================================================== */

function normalizeStatus(
    status
) {

    const value =
        String(
            status || 'todo'
        )
            .toLowerCase()
            .replace(/-/g, '_')
            .replace(/ /g, '_');


    if (
        value === 'completed' ||
        value === 'complete'
    ) {

        return 'done';
    }


    if (
        value === 'progress' ||
        value === 'inprogress'
    ) {

        return 'in_progress';
    }


    if (
        value !== 'todo' &&
        value !== 'in_progress' &&
        value !== 'done'
    ) {

        return 'todo';
    }


    return value;
}


/* =====================================================
   RENDER TASK COLUMN
===================================================== */

function renderTaskColumn(
    title,
    tasks
) {

    return `

        <div class="column">

            <div class="column-header">

                <h4>
                    ${title}
                </h4>

                <span class="task-count">
                    ${tasks.length}
                </span>

            </div>


            ${
                tasks.length

                    ? tasks
                        .map(task => {

                            return renderTask(
                                task
                            );

                        })
                        .join('')

                    : `

                        <p class="muted small">
                            No tasks
                        </p>

                    `
            }

        </div>

    `;
}


/* =====================================================
   RENDER SINGLE TASK
===================================================== */

function renderTask(
    task
) {

    const status =
        normalizeStatus(
            task.status
        );


    const taskId =
        Number(
            task.id
        );


    const assignee =
        task.assignee_name ||
        task.assignee ||
        (
            task.assignee_id
                ? `User #${task.assignee_id}`
                : ''
        );


    return `

        <div class="task">

            <div class="task-title">

                ${escapeHtml(
                    task.title ||
                    task.name ||
                    'Untitled task'
                )}

            </div>


            ${
                task.description
                    ? `
                        <div class="task-description">

                            ${escapeHtml(
                                task.description
                            )}

                        </div>
                      `
                    : ''
            }


            <div class="task-meta">

                <span class="task-status">
                    ${statusLabel(status)}
                </span>


                ${
                    assignee
                        ? `
                            <span class="task-assignee">

                                👤
                                ${escapeHtml(
                                    assignee
                                )}

                            </span>
                          `
                        : ''
                }

            </div>


            ${
                taskId
                    ? `
                        <div class="task-actions">

                            ${
                                status !== 'todo'
                                    ? `
                                        <button
                                            class="btn secondary"
                                            type="button"
                                            onclick="updateTaskStatus(${taskId}, 'todo', ${task.project_id || task.projectId || 0})"
                                        >
                                            To Do
                                        </button>
                                      `
                                    : ''
                            }


                            ${
                                status !== 'in_progress'
                                    ? `
                                        <button
                                            class="btn secondary"
                                            type="button"
                                            onclick="updateTaskStatus(${taskId}, 'in_progress', ${task.project_id || task.projectId || 0})"
                                        >
                                            In Progress
                                        </button>
                                      `
                                    : ''
                            }


                            ${
                                status !== 'done'
                                    ? `
                                        <button
                                            class="btn success"
                                            type="button"
                                            onclick="updateTaskStatus(${taskId}, 'done', ${task.project_id || task.projectId || 0})"
                                        >
                                            Done
                                        </button>
                                      `
                                    : ''
                            }

                        </div>
                      `
                    : ''
            }

        </div>

    `;
}


/* =====================================================
   STATUS LABEL
===================================================== */

function statusLabel(
    status
) {

    if (status === 'in_progress') {
        return 'In Progress';
    }

    if (status === 'done') {
        return 'Done';
    }

    return 'To Do';
}


/* =====================================================
   CREATE TASK
===================================================== */

async function createTask(
    projectId
) {

    if (!token) {

        toast(
            'Please login first.'
        );

        return;
    }


    const title =
        $(`#task-title-${projectId}`)
            ?.value
            .trim();


    const description =
        $(`#task-description-${projectId}`)
            ?.value
            .trim();


    const status =
        $(`#task-status-${projectId}`)
            ?.value ||
        'todo';


    const assigneeValue =
        $(`#task-assignee-${projectId}`)
            ?.value
            .trim();


    if (!title) {

        toast(
            'Enter a task title.'
        );

        return;
    }


    const body = {

        title,

        description,

        status

    };


    if (assigneeValue) {

        body.assignee_id =
            Number(
                assigneeValue
            );
    }


    try {

        const response =
            await fetch(
                `/api/projects/${encodeURIComponent(
                    projectId
                )}/tasks`,
                {
                    method: 'POST',

                    headers:
                        authHeaders(),

                    body:
                        JSON.stringify(
                            body
                        )
                }
            );


        if (
            response.status === 401
        ) {

            handleUnauthorized();

            return;
        }


        const data =
            await safeJson(
                response
            );


        if (!response.ok) {

            toast(
                data.message ||
                'Could not create task.'
            );

            return;
        }


        toast(
            data.message ||
            'Task created successfully.'
        );


        /*
         * Reload tasks so the new
         * task appears immediately.
         */

        await loadProjectTasks(
            projectId
        );


        /*
         * Refresh notifications because
         * creating a task may generate
         * a notification.
         */

        loadNotifications();

    } catch (error) {

        console.error(
            'Create task error:',
            error
        );

        toast(
            'Cannot connect to server.'
        );
    }
}


/* =====================================================
   UPDATE TASK STATUS
===================================================== */

async function updateTaskStatus(
    taskId,
    status,
    projectId
) {

    if (!taskId) {

        toast(
            'Invalid task ID.'
        );

        return;
    }


    try {

        const response =
            await fetch(
                `/api/tasks/${encodeURIComponent(
                    taskId
                )}`,
                {
                    method: 'PUT',

                    headers:
                        authHeaders(),

                    body:
                        JSON.stringify({
                            status
                        })
                }
            );


        if (
            response.status === 401
        ) {

            handleUnauthorized();

            return;
        }


        const data =
            await safeJson(
                response
            );


        if (!response.ok) {

            toast(
                data.message ||
                'Could not update task.'
            );

            return;
        }


        toast(
            data.message ||
            'Task updated.'
        );


        if (projectId) {

            loadProjectTasks(
                projectId
            );
        }


        loadNotifications();

    } catch (error) {

        console.error(
            error
        );

        toast(
            'Cannot update task.'
        );
    }
}


/* =====================================================
   LOAD NOTIFICATIONS
===================================================== */

async function loadNotifications() {

    const list =
        $('#notificationsList');


    if (!list) {
        return;
    }


    if (!token) {

        list.innerHTML = `

            <div class="card empty">
                Login to view notifications.
            </div>

        `;

        return;
    }


    list.innerHTML = `

        <div class="card empty">
            Loading notifications...
        </div>

    `;


    try {

        const response =
            await fetch(
                '/api/notifications',
                {
                    method: 'GET',

                    headers:
                        authHeaders()
                }
            );


        if (
            response.status === 401
        ) {

            handleUnauthorized();

            return;
        }


        const data =
            await safeJson(
                response
            );


        if (!response.ok) {

            throw new Error(
                data.message ||
                'Could not load notifications.'
            );
        }


        const notifications =
            Array.isArray(data)
                ? data
                : (
                    Array.isArray(
                        data.notifications
                    )
                        ? data.notifications
                        : []
                );


        renderNotifications(
            notifications
        );


    } catch (error) {

        console.error(
            'Notification error:',
            error
        );


        list.innerHTML = `

            <div class="card">

                <strong>
                    Could not load notifications.
                </strong>

                <p class="muted">
                    ${escapeHtml(
                        error.message
                    )}
                </p>


                <button
                    class="btn"
                    type="button"
                    onclick="loadNotifications()"
                >
                    Retry
                </button>

            </div>

        `;
    }
}


/* =====================================================
   RENDER NOTIFICATIONS
===================================================== */

function renderNotifications(
    notifications
) {

    const list =
        $('#notificationsList');


    /*
     * Calculate unread count.
     */

    const unreadCount =
        notifications.filter(
            notification =>
                !isNotificationRead(
                    notification
                )
        ).length;


    updateNotificationBadge(
        unreadCount
    );


    if (!notifications.length) {

        list.innerHTML = `

            <div class="card empty">

                🔔

                <br>

                No notifications yet.

            </div>

        `;

        return;
    }


    list.innerHTML = `

        <div class="notification-list">

            ${
                notifications
                    .map(
                        notification =>
                            renderNotification(
                                notification
                            )
                    )
                    .join('')
            }

        </div>

    `;
}


/* =====================================================
   RENDER SINGLE NOTIFICATION
===================================================== */

function renderNotification(
    notification
) {

    const id =
        Number(
            notification.id
        );


    const read =
        isNotificationRead(
            notification
        );


    const message =
        notification.message ||
        notification.text ||
        notification.content ||
        'New notification';


    const date =
        notification.created_at ||
        notification.createdAt;


    return `

        <div
            class="
                notification
                ${read ? '' : 'unread'}
            "
        >

            <div class="notification-content">

                <div
                    class="notification-message"
                >

                    ${
                        read
                            ? ''
                            : '<strong>New</strong> '
                    }

                    ${escapeHtml(
                        message
                    )}

                </div>


                <div
                    class="notification-time"
                >

                    ${formatDate(
                        date
                    )}

                </div>

            </div>


            ${
                !read && id
                    ? `
                        <div
                            class="notification-actions"
                        >

                            <button
                                class="btn secondary"
                                type="button"
                                onclick="markNotificationRead(${id})"
                            >
                                Mark read
                            </button>

                        </div>
                      `
                    : ''
            }

        </div>

    `;
}


/* =====================================================
   CHECK NOTIFICATION READ STATUS
===================================================== */

function isNotificationRead(
    notification
) {

    if (
        notification.read === true
    ) {
        return true;
    }


    if (
        notification.is_read === true
    ) {
        return true;
    }


    if (
        notification.read_at
    ) {
        return true;
    }


    return false;
}


/* =====================================================
   NOTIFICATION BADGE
===================================================== */

function updateNotificationBadge(
    count
) {

    const badge =
        $('#notificationBadge');


    if (!badge) {
        return;
    }


    if (count > 0) {

        badge.textContent =
            count > 99
                ? '99+'
                : count;


        badge.classList.remove(
            'hidden'
        );

    } else {

        badge.classList.add(
            'hidden'
        );
    }
}


/* =====================================================
   MARK ONE NOTIFICATION READ
===================================================== */

async function markNotificationRead(
    notificationId
) {

    try {

        const response =
            await fetch(
                `/api/notifications/${encodeURIComponent(
                    notificationId
                )}/read`,
                {
                    method: 'PUT',

                    headers:
                        authHeaders()
                }
            );


        if (
            response.status === 401
        ) {

            handleUnauthorized();

            return;
        }


        const data =
            await safeJson(
                response
            );


        if (!response.ok) {

            toast(
                data.message ||
                'Could not mark notification as read.'
            );

            return;
        }


        toast(
            data.message ||
            'Notification marked as read.'
        );


        loadNotifications();

    } catch (error) {

        console.error(
            error
        );

        toast(
            'Cannot update notification.'
        );
    }
}


/* =====================================================
   MARK ALL NOTIFICATIONS READ
===================================================== */

async function markAllNotificationsRead() {

    if (!token) {

        toast(
            'Please login first.'
        );

        return;
    }


    try {

        const response =
            await fetch(
                '/api/notifications/read-all',
                {
                    method: 'PUT',

                    headers:
                        authHeaders()
                }
            );


        if (
            response.status === 401
        ) {

            handleUnauthorized();

            return;
        }


        const data =
            await safeJson(
                response
            );


        if (!response.ok) {

            toast(
                data.message ||
                'Could not mark notifications as read.'
            );

            return;
        }


        toast(
            data.message ||
            'All notifications marked as read.'
        );


        loadNotifications();

    } catch (error) {

        console.error(
            error
        );

        toast(
            'Cannot update notifications.'
        );
    }
}


/* =====================================================
   UNAUTHORIZED
===================================================== */

function handleUnauthorized() {

    token = null;


    localStorage.removeItem(
        'projectflow_token'
    );


    updateAuthUI();


    toast(
        'Session expired. Please login again.'
    );
}


/* =====================================================
   CLOSE MODAL WHEN CLICK OUTSIDE
===================================================== */

document.addEventListener(
    'click',
    event => {

        const modal =
            $('#modal');


        if (
            modal &&
            event.target === modal
        ) {

            closeAuth();
        }

    }
);


/* =====================================================
   ESC CLOSE MODAL
===================================================== */

document.addEventListener(
    'keydown',
    event => {

        if (
            event.key === 'Escape'
        ) {

            closeAuth();
        }

    }
);


/* =====================================================
   INITIALIZE
===================================================== */

document.addEventListener(
    'DOMContentLoaded',
    () => {

        token =
            localStorage.getItem(
                'projectflow_token'
            );


        updateAuthUI();


        if (token) {

            loadProjects();

            loadNotifications();

        }

    }
);