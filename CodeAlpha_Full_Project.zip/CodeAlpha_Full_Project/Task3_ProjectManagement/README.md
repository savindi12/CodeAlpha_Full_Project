# Task 3 – Project Management Tool

Implements the Trello/Asana-style requirements: authentication, group projects, project boards, task cards, task assignment, task comments/communication, and backend management of users/projects/tasks/comments. It also includes Socket.IO real-time task/notification events as the assignment bonus.

Run `database.sql`, then `npm install`, configure `.env`, and `npm start`. Open http://localhost:3003.

### Workflow
1. Register/login.
2. Create a project.
3. Open the board.
4. Create tasks, assign members, set priority/due date.
5. Move cards through Todo → In Progress → Done.
6. Comment on task cards.
7. Socket.IO refreshes connected project boards when tasks change.
