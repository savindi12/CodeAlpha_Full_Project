require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'task1_ecommerce',
  waitForConnections: true,
  connectionLimit: 10,
  decimalNumbers: true
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

function createToken(user) {
  return jwt.sign({ id: user.id, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
}
function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Please login first.' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { return res.status(401).json({ message: 'Session expired. Please login again.' }); }
}

app.get('/api/products', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id,name,description,price,image,stock FROM products ORDER BY id DESC');
    res.json(rows);
  } catch (e) { res.status(500).json({ message: 'Unable to load products.' }); }
});

app.get('/api/products/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id,name,description,price,image,stock FROM products WHERE id=?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ message: 'Product not found.' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: 'Unable to load product.' }); }
});

app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6) return res.status(400).json({ message: 'Name, email and a password of at least 6 characters are required.' });
  try {
    const [existing] = await pool.query('SELECT id FROM users WHERE email=?', [email.toLowerCase().trim()]);
    if (existing.length) return res.status(409).json({ message: 'Email is already registered.' });
    const hash = await bcrypt.hash(password, 10);
    const [result] = await pool.query('INSERT INTO users(name,email,password) VALUES(?,?,?)', [name.trim(), email.toLowerCase().trim(), hash]);
    const user = { id: result.insertId, name: name.trim(), email: email.toLowerCase().trim() };
    res.status(201).json({ message: 'Registration successful.', token: createToken(user), user });
  } catch (e) { res.status(500).json({ message: 'Registration failed.' }); }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ message: 'Email and password are required.' });
  try {
    const [rows] = await pool.query('SELECT id,name,email,password FROM users WHERE email=?', [email.toLowerCase().trim()]);
    if (!rows.length || !(await bcrypt.compare(password, rows[0].password))) return res.status(401).json({ message: 'Invalid email or password.' });
    const user = { id: rows[0].id, name: rows[0].name, email: rows[0].email };
    res.json({ message: 'Login successful.', token: createToken(user), user });
  } catch (e) { res.status(500).json({ message: 'Login failed.' }); }
});

app.get('/api/me', auth, async (req, res) => res.json({ user: req.user }));

app.post('/api/orders', async (req, res) => {
  const { customer, items, paymentMethod } = req.body;
  if (!customer || !customer.name || !customer.email || !customer.phone || !customer.address || !customer.city) return res.status(400).json({ message: 'Complete delivery details are required.' });
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ message: 'Your cart is empty.' });
  if (!['CARD','CASH_ON_DELIVERY'].includes(paymentMethod)) return res.status(400).json({ message: 'Invalid payment method.' });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    let total = 0;
    const checkedItems = [];
    for (const item of items) {
      const qty = Math.max(1, Number(item.quantity || 1));
      const [rows] = await conn.query('SELECT id,name,price,stock FROM products WHERE id=? FOR UPDATE', [item.id]);
      if (!rows.length) throw new Error(`Product ${item.id} was not found.`);
      if (rows[0].stock < qty) throw new Error(`${rows[0].name} has only ${rows[0].stock} item(s) available.`);
      const subtotal = Number(rows[0].price) * qty;
      total += subtotal;
      checkedItems.push({ ...rows[0], quantity: qty, subtotal });
    }
    const tokenHeader = req.headers.authorization || '';
    let userId = null;
    if (tokenHeader.startsWith('Bearer ')) { try { userId = jwt.verify(tokenHeader.slice(7), JWT_SECRET).id; } catch {} }
    const paymentStatus = paymentMethod === 'CARD' ? 'PAID' : 'COD_PENDING';
    const [order] = await conn.query(
      'INSERT INTO orders(user_id,customer_name,email,phone,address,city,total,payment_method,payment_status) VALUES(?,?,?,?,?,?,?,?,?)',
      [userId, customer.name, customer.email, customer.phone, customer.address, customer.city, total, paymentMethod, paymentStatus]
    );
    for (const item of checkedItems) {
      await conn.query('INSERT INTO order_items(order_id,product_id,product_name,price,quantity,subtotal) VALUES(?,?,?,?,?,?)', [order.insertId,item.id,item.name,item.price,item.quantity,item.subtotal]);
      await conn.query('UPDATE products SET stock=stock-? WHERE id=?', [item.quantity,item.id]);
    }
    await conn.commit();
    res.status(201).json({ message: 'Order placed successfully.', orderId: order.insertId, total, paymentStatus });
  } catch (e) {
    await conn.rollback();
    res.status(400).json({ message: e.message || 'Order could not be placed.' });
  } finally { conn.release(); }
});

app.get('/api/orders', auth, async (req, res) => {
  try {
    const [orders] = await pool.query('SELECT id,total,payment_method,payment_status,order_status,created_at FROM orders WHERE user_id=? ORDER BY id DESC', [req.user.id]);
    for (const order of orders) {
      const [items] = await pool.query('SELECT product_name,price,quantity,subtotal FROM order_items WHERE order_id=?', [order.id]);
      order.items = items;
    }
    res.json(orders);
  } catch (e) { res.status(500).json({ message: 'Unable to load orders.' }); }
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, async () => {
  try { await pool.query('SELECT 1'); console.log(`Database connected. Server running at http://localhost:${PORT}`); }
  catch (e) { console.log(`Server running at http://localhost:${PORT} (database connection will retry on API requests)`); }
});
