CREATE DATABASE IF NOT EXISTS task1_ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE task1_ecommerce;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  image VARCHAR(255) NOT NULL,
  stock INT NOT NULL DEFAULT 20,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  customer_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  address VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  payment_method ENUM('CARD','CASH_ON_DELIVERY') NOT NULL,
  payment_status ENUM('PENDING','PAID','COD_PENDING','FAILED') NOT NULL DEFAULT 'PENDING',
  order_status ENUM('PLACED','PROCESSING','SHIPPED','DELIVERED','CANCELLED') NOT NULL DEFAULT 'PLACED',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  product_name VARCHAR(150) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  quantity INT NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
);

INSERT INTO products (name, description, price, image, stock) VALUES
('Wireless Headphones','Comfortable Bluetooth headphones with deep bass, built-in microphone and long battery life.',12990.00,'/images/headphones.svg',25),
('Smart Watch Pro','Fitness tracking, heart-rate monitoring, notifications and a bright touch display.',18990.00,'/images/smartwatch.svg',18),
('Mechanical Keyboard','RGB mechanical keyboard with tactile switches and a compact premium design.',14990.00,'/images/keyboard.svg',30),
('Gaming Mouse','Ergonomic high-precision gaming mouse with adjustable DPI and RGB lighting.',7990.00,'/images/mouse.svg',35),
('Portable Speaker','Water-resistant Bluetooth speaker with powerful sound and all-day battery.',9990.00,'/images/speaker.svg',22),
('USB-C Laptop Stand','Adjustable aluminium laptop stand suitable for home, office and study setups.',6990.00,'/images/stand.svg',40)
ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description), price=VALUES(price), image=VALUES(image), stock=VALUES(stock);
