# CodeAlpha Task 1 – Complete E-commerce Store

## Features
- Product listing with local product images
- Product details page
- Shopping cart with quantity controls and remove
- User registration and login with bcrypt + JWT
- MySQL database for users, products, orders and order items
- Checkout and delivery details
- Demo card payment flow (records payment as PAID; no real money is charged)
- Cash on Delivery
- Order history
- Stock validation and stock reduction when an order is placed
- Responsive HTML/CSS/JavaScript frontend
- Express.js backend

## Windows setup
1. Install Node.js LTS and XAMPP/MySQL.
2. Copy `.env.example` to `.env` and set your MySQL username/password.
3. Open MySQL Workbench or phpMyAdmin.
4. Run all SQL in `database.sql`.
5. Open CMD/PowerShell in this folder and run:
   `npm install`
6. Start:
   `npm start`
7. Open `http://localhost:3000`.

## Demo card
Use any 16-digit number, e.g. `4111111111111111`, with any expiry/CVV for the assignment demo. This project does NOT charge a real card.

## Important
For real online payments, connect a payment gateway such as PayHere/Stripe and keep secret keys on the server. Do not store raw card numbers or CVV in the database.
